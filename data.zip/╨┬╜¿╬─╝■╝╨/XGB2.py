"""
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler, normalize
from xgboost import XGBRegressor
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-new-ppppp.xlsx'
data = pd.read_excel(file_path)

# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=41)

# 将数据集转换为DMatrix格式
dtrain = xgb.DMatrix(X_train, label=y_train)
dtest = xgb.DMatrix(X_test)

# 参数网格
param_grid = {
    'n_estimators': [200, 250],
    'max_depth': [5, 9],
    'learning_rate': [0.1, 0.5],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.6, 0.8],
    'gamma': [0.1, 0.5],
    'min_child_weight': [3, 5]
}

# 网格搜索
grid_search = GridSearchCV(XGBRegressor(), param_grid, cv=5, scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)

# 最佳参数
print("Best parameters found: ", grid_search.best_params_)
print("Best cross-validation score: ", grid_search.best_score_)

# 使用最佳参数训练模型
model = grid_search.best_estimator_

# 拟合模型
model.fit(X_train, y_train)

# 预测测试集数据
y_pred_test = model.predict(X_test)
# 预测训练集数据
y_pred_train = model.predict(X_train)

# 计算均方误差（MSE）
test_mse = mean_squared_error(y_test, y_pred_test)
print("测试集均方误差 (MSE): %.2f" % test_mse)

# 计算决定系数（R^2）
test_r2 = r2_score(y_test, y_pred_test)
print("测试集决定系数 (R^2): %.2f" % test_r2)

# 计算训练集的均方误差（MSE）
train_mse = mean_squared_error(y_train, y_pred_train)
print("训练集均方误差 (MSE): %.2f" % train_mse)

# 计算训练集的决定系数（R^2）
train_r2 = r2_score(y_train, y_pred_train)
print("训练集决定系数 (R^2): %.2f" % train_r2)

# 计算拟合直线的斜率和截距
def calculate_fit(y_true, y_pred):
    slope, intercept = np.polyfit(y_true, y_pred, 1)
    return slope, intercept

test_slope, test_intercept = calculate_fit(y_test, y_pred_test)
train_slope, train_intercept = calculate_fit(y_train, y_pred_train)

# 计算置信区间和预测区间
def get_confidence_prediction_bands(y_true, y_pred, confidence=0.95):
    n = len(y_true)
    se = np.sqrt(np.sum((y_true - y_pred) ** 2) / (n - 2))
    t_value = 1.96  # for 95% confidence interval

    pred_band = t_value * se * np.sqrt(1 + 1/n)
    conf_band = t_value * se * np.sqrt(1 / n)

    return conf_band, pred_band

test_conf_band, test_pred_band = get_confidence_prediction_bands(y_test, y_pred_test)
train_conf_band, train_pred_band = get_confidence_prediction_bands(y_train, y_pred_train)

# 绘制拟合图像的函数
def plot_fit(y_true, y_pred, slope, intercept, conf_band, pred_band, title, r2):
    plt.figure(figsize=(8, 6))
    ax = plt.gca()
    ax.spines['bottom'].set_linewidth(1)
    ax.spines['left'].set_linewidth(1)
    ax.spines['right'].set_linewidth(1)
    ax.spines['top'].set_linewidth(1)

    plt.xlim(y_true.min() - 0.2, y_true.max())

    plt.plot([y_true.min(), y_true.max()],
             [slope*y_true.min()+intercept, slope*y_true.max()+intercept],
             color='black',
             linestyle='dashdot',
             linewidth=1.5,
             alpha=0.6,
             label='Linear Fit')

    plt.scatter(y_pred, y_true, color='#CD1076', marker='o', alpha=0.9, label='Data', edgecolor='black', s=70, linewidth=0.5)

    plt.fill_between([y_true.min(), y_true.max()],
                     [slope*y_true.min()+intercept-conf_band, slope*y_true.max()+intercept-conf_band],
                     [slope*y_true.min()+intercept+conf_band, slope*y_true.max()+intercept+conf_band],
                     color='darkgray',
                     alpha=0.5,
                     label='95% Confidence Band')

    plt.fill_between([y_true.min(), y_true.max()],
                     [slope*y_true.min()+intercept-pred_band, slope*y_true.max()+intercept-pred_band],
                     [slope*y_true.min()+intercept+pred_band, slope*y_true.max()+intercept+pred_band],
                     color='lightgray',
                     alpha=0.3,
                     label='95% Prediction Band')

    plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
    plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
    plt.xticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')
    plt.yticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')
    plt.tick_params(axis='both', direction='in', length=3)

    plt.legend(loc='upper left', frameon=False, prop={'weight': 'normal', 'size': 22, 'family': 'Arial'})

    plt.text(0.62, 0.02, f'Fitting equation:\ny = {slope:.2f}x + {intercept:.2f}\nR²: {r2:.2f}',
             fontsize=25, color='black', ha='left', va='bottom', fontname='Arial', fontweight='normal', transform=ax.transAxes)

    plt.grid(False)
    plt.tight_layout()
    plt.savefig('D:/PyCharm/Py_Project/PFAS/123/XGBoost-{title}_fit.png', dpi=600)
    plt.show()

# 绘制测试集和训练集的拟合图像
plot_fit(y_test, y_pred_test, test_slope, test_intercept, test_conf_band, test_pred_band, "test", test_r2)
plot_fit(y_train, y_pred_train, train_slope, train_intercept, train_conf_band, train_pred_band, "train", train_r2)
"""



#PCA  C和F《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import MinMaxScaler, normalize
from xgboost import XGBRegressor
from sklearn.decomposition import PCA
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# ------------------ 新增：对C和F做PCA --------------------------------------
# 假设数据集中存在 'C' 和 'F' 两列
cf_features = data[['C', 'F']]

# 标准化
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

# PCA，降到1个主成分（或者2个，你可以改 n_components=2）
pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

# 将 PCA 结果替换原始 C、F 特征
data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca



# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=41)

# 将数据集转换为DMatrix格式
dtrain = xgb.DMatrix(X_train, label=y_train)
dtest = xgb.DMatrix(X_test)

# 参数网格
param_grid = {
    'n_estimators': [200, 250],
    'max_depth': [5, 9],
    'learning_rate': [0.1, 0.5],
    'subsample': [0.8, 1.0],
    'colsample_bytree': [0.6, 0.8],
    'gamma': [0.1, 0.5],
    'min_child_weight': [3, 5]
}

# 网格搜索
grid_search = GridSearchCV(XGBRegressor(), param_grid, cv=5, scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)

# 最佳参数
print("Best parameters found: ", grid_search.best_params_)
print("Best cross-validation score: ", grid_search.best_score_)

# 使用最佳参数训练模型
model = grid_search.best_estimator_

# 拟合模型
model.fit(X_train, y_train)

# 预测测试集数据
y_pred_test = model.predict(X_test)
# 预测训练集数据
y_pred_train = model.predict(X_train)

# 计算均方误差（MSE）
test_mse = mean_squared_error(y_test, y_pred_test)
print("测试集均方误差 (MSE): %.2f" % test_mse)

# 计算决定系数（R^2）
test_r2 = r2_score(y_test, y_pred_test)
print("测试集决定系数 (R^2): %.2f" % test_r2)

# 计算训练集的均方误差（MSE）
train_mse = mean_squared_error(y_train, y_pred_train)
print("训练集均方误差 (MSE): %.2f" % train_mse)

# 计算训练集的决定系数（R^2）
train_r2 = r2_score(y_train, y_pred_train)
print("训练集决定系数 (R^2): %.2f" % train_r2)

# 计算拟合直线的斜率和截距
def calculate_fit(y_true, y_pred):
    slope, intercept = np.polyfit(y_true, y_pred, 1)
    return slope, intercept

test_slope, test_intercept = calculate_fit(y_test, y_pred_test)
train_slope, train_intercept = calculate_fit(y_train, y_pred_train)

# 计算置信区间和预测区间
def get_confidence_prediction_bands(y_true, y_pred, confidence=0.95):
    n = len(y_true)
    se = np.sqrt(np.sum((y_true - y_pred) ** 2) / (n - 2))
    t_value = 1.96  # for 95% confidence interval

    pred_band = t_value * se * np.sqrt(1 + 1/n)
    conf_band = t_value * se * np.sqrt(1 / n)

    return conf_band, pred_band

test_conf_band, test_pred_band = get_confidence_prediction_bands(y_test, y_pred_test)
train_conf_band, train_pred_band = get_confidence_prediction_bands(y_train, y_pred_train)

# 绘制拟合图像的函数
def plot_fit(y_true, y_pred, slope, intercept, conf_band, pred_band, title, r2):
    plt.figure(figsize=(8, 6))
    ax = plt.gca()
    ax.spines['bottom'].set_linewidth(1)
    ax.spines['left'].set_linewidth(1)
    ax.spines['right'].set_linewidth(1)
    ax.spines['top'].set_linewidth(1)

    plt.xlim(y_true.min() - 0.2, y_true.max())

    plt.plot([y_true.min(), y_true.max()],
             [slope*y_true.min()+intercept, slope*y_true.max()+intercept],
             color='black',
             linestyle='dashdot',
             linewidth=1.5,
             alpha=0.6,
             label='Linear Fit')

    plt.scatter(y_pred, y_true, color='#CD1076', marker='o', alpha=0.9, label='Data', edgecolor='black', s=70, linewidth=0.5)

    plt.fill_between([y_true.min(), y_true.max()],
                     [slope*y_true.min()+intercept-conf_band, slope*y_true.max()+intercept-conf_band],
                     [slope*y_true.min()+intercept+conf_band, slope*y_true.max()+intercept+conf_band],
                     color='darkgray',
                     alpha=0.5,
                     label='95% Confidence Band')

    plt.fill_between([y_true.min(), y_true.max()],
                     [slope*y_true.min()+intercept-pred_band, slope*y_true.max()+intercept-pred_band],
                     [slope*y_true.min()+intercept+pred_band, slope*y_true.max()+intercept+pred_band],
                     color='lightgray',
                     alpha=0.3,
                     label='95% Prediction Band')

    plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
    plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
    plt.xticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')
    plt.yticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')
    plt.tick_params(axis='both', direction='in', length=3)

    plt.legend(loc='upper left', frameon=False, prop={'weight': 'normal', 'size': 22, 'family': 'Arial'})

    plt.text(0.62, 0.02, f'Fitting equation:\ny = {slope:.2f}x + {intercept:.2f}\nR²: {r2:.2f}',
             fontsize=25, color='black', ha='left', va='bottom', fontname='Arial', fontweight='normal', transform=ax.transAxes)

    plt.grid(False)
    plt.tight_layout()
    plt.savefig(f'D:/PyCharm/Py_Project/PFAS/123/XGBoost-{title}_fit.png', dpi=600)
    plt.show()

# 绘制测试集和训练集的拟合图像
plot_fit(y_test, y_pred_test, test_slope, test_intercept, test_conf_band, test_pred_band, "test", test_r2)
plot_fit(y_train, y_pred_train, train_slope, train_intercept, train_conf_band, train_pred_band, "train", train_r2)
