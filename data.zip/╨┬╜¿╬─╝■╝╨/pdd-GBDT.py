"""
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.inspection import PartialDependenceDisplay
from sklearn.impute import SimpleImputer
from time import time

# 设置全局字体大小
plt.rcParams.update({'font.size': 42, 'font.family': 'Arial', 'font.weight': 'normal'})

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所 有列
y = data.iloc[:, -1]  # 因变量，选择最后一列


# 处理缺失值
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 获取特征名称
features = list(data.columns[:-1])  # 使用原始的 DataFrame 获取特征名称

# 确保 X_train 是 DataFrame 类型
X_train_df = pd.DataFrame(X, columns=features)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=43)

# 创建GBDT回归模型
gbdt = GradientBoostingRegressor(
    n_estimators=100,  # 基学习器的数量
    max_depth=3,       # 决策树的最大深度
    learning_rate=0.1, # 学习率
    min_samples_split=5,
    min_samples_leaf=5,
    init=None,
    random_state=40
)

# 拟合模型
gbdt.fit(X_train, y_train)

# 获取训练数据的预测残差
residuals = y_train - gbdt.predict(X_train)

# 使用残差校正偏依赖图
for feature in features:
    display = PartialDependenceDisplay.from_estimator(
        gbdt, X_train_df, features=[feature], kind='average'
    )
    for ax_ in display.axes_.ravel():
        for line in ax_.lines:
            # 根据残差进行校正
            line.set_ydata(line.get_ydata() + residuals.mean())


# 计时开始
tic = time()

print('Computing partial dependence plots...')
for feature in features:
    fig, ax = plt.subplots(figsize=(12, 9))
    display = PartialDependenceDisplay.from_estimator(
        gbdt, X_train_df, features=[feature], kind='average', grid_resolution=15, ax=ax
    )


    ax.set_ylim([0.25, 1.25])
    ax.figure.canvas.draw()

    for ax_ in display.axes_.ravel():
        ax_.set_ylabel('Predicted qₑ(mg/g)', labelpad=10, fontsize=42)
        ax_.set_xlabel(feature, fontsize=42)
        ax_.tick_params(axis='both', which='major', labelsize=42)

        for line in ax_.lines:
            line.set_linewidth(4)


    feature_cleaned = feature.replace(" ", "_").replace("(", "_").replace(")", "_").replace("/", "_")
    fig.tight_layout()
    fig.savefig(f'D:/PyCharm/Py_Project/PFAS/pddGBDT-ppppp/partial_dependence_{feature_cleaned}.png',
                bbox_inches='tight', dpi=100)
    plt.close(fig)

print(f"done in {time() - tic:.3f}s")
"""



#PAC  C和F《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.inspection import PartialDependenceDisplay
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA
from time import time


# 设置全局字体
plt.rcParams.update({'font.size': 42, 'font.family': 'Arial', 'font.weight': 'normal'})
plt.rcParams['font.family'] = 'DejaVu Sans'


# 读取数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# 批量替换指定列名
data.rename(columns=lambda x: x.replace("BET(m2/g)", "BET (m²/g)"), inplace=True)

# 提取自变量和因变量
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 缺失值处理
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 创建 DataFrame
features = list(data.columns[:-1])
X_df = pd.DataFrame(X, columns=features)

# 对 C 和 F 做 PCA
pca = PCA(n_components=1)
X_df['C_F_PC'] = pca.fit_transform(X_df[['C', 'F']])
# 删除原来的 C 和 F
X_df.drop(['C', 'F'], axis=1, inplace=True)

# 更新特征列表
features = list(X_df.columns)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X_df, y, test_size=0.2, random_state=43)

# 创建 GBDT 模型
gbdt = GradientBoostingRegressor(
    n_estimators=100,
    max_depth=3,
    learning_rate=0.1,
    min_samples_split=5,
    min_samples_leaf=5,
    random_state=40
)

# 拟合模型
gbdt.fit(X_train, y_train)

# 计时开始
tic = time()

print('Computing partial dependence plots...')
save_path = 'D:/PyCharm/Py_Project/PFAS/pddGBDT-ppppp/'

for feature in features:
    fig, ax = plt.subplots(figsize=(12, 9))
    display = PartialDependenceDisplay.from_estimator(
        gbdt, X_train, features=[feature], kind='average', grid_resolution=15, ax=ax
    )

    # 强制覆盖 y 轴标签
    display.axes_[0, 0].set_ylabel('Predicted qₑ(mg/g)', fontsize=42, labelpad=10)
    display.axes_[0, 0].set_xlabel(feature, fontsize=42)
    display.axes_[0, 0].tick_params(axis='both', which='major', labelsize=42)

    for line in display.lines_[0]:
        line.set_linewidth(4)

    #ax.set_ylabel('Predicted qₑ(mg/g)', fontsize=42, labelpad=10)
    #ax.set_xlabel(feature, fontsize=42)
    #ax.tick_params(axis='both', which='major', labelsize=42)
    #for line in ax.lines:
     #   line.set_linewidth(4)

    feature_cleaned = feature.replace(" ", "_").replace("(", "_").replace(")", "_").replace("/", "_")
    fig.tight_layout()
    fig.savefig(f'{save_path}partial_dependence_{feature_cleaned}.png', bbox_inches='tight', dpi=100)
    plt.close(fig)

print(f"done in {time() - tic:.3f}s")



