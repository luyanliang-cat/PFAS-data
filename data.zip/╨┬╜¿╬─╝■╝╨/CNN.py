"""
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)


# ------------------ 新增：对C和F做PCA --------------------------------------
# 假设数据集中存在 'C' 和 'F' 两列
cf_features = data[['C', 'F']]

# 标准化
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

# PCA，降到1个主成分（或者2个，你可以改 n_components=2）
pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

# 将 PCA 结果替换原始 C、F 特征
data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca



# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=41)

# 创建自定义数据集类
class CustomDataset(Dataset):
    def __init__(self, X, y):
        self.data = torch.tensor(X.values, dtype=torch.float32)
        self.targets = torch.tensor(y.values, dtype=torch.float32)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample, label = self.data[idx], self.targets[idx]
        return sample, label

# 创建CNN模型类
class CNNModel(nn.Module):
    def __init__(self):
        super(CNNModel, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3)
        self.fc1 = nn.Linear(16*12, 64)
        self.fc2 = nn.Linear(64, 1)

    def forward(self, x):
        x = x.unsqueeze(1)  # 在通道维度上增加一个维度
        x = self.conv1(x)
        x = torch.relu(x)
        x = x.view(-1, 16*12)  # 将卷积层输出展平
        x = self.fc1(x)
        x = torch.relu(x)
        x = self.fc2(x)
        return x

# 设置超参数和设备
input_size = 14
learning_rate = 0.000
num_epochs = 100
batch_size = 16
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 创建数据集和数据加载器
dataset = CustomDataset(X_train, y_train)
dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

# 创建模型实例并移动到设备
model = CNNModel().to(device)

# 定义损失函数和优化器
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)

# 训练模型
for epoch in range(num_epochs):
    for inputs, labels in dataloader:
        inputs, labels = inputs.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
    if (epoch+1) % 10 == 0:
        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')

# 保存模型
torch.save(model.state_dict(), 'cnn_model.pth')

# 定义设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 创建CNNModel模型实例
model = CNNModel()

# 加载已保存的模型参数
model.load_state_dict(torch.load('cnn_model.pth'))

# 将模型移动到相同的设备上
model.to(device)

# 设置模型为评估模式
model.eval()

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# ------------------ 新增：对C和F做PCA --------------------------------------
# 假设数据集中存在 'C' 和 'F' 两列
cf_features = data[['C', 'F']]

# 标准化
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

# PCA，降到1个主成分（或者2个，你可以改 n_components=2）
pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

# 将 PCA 结果替换原始 C、F 特征
data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca


# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]  # 因变量，选择最后一列

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=17)
y_train_np = y_train.values  # 将Pandas Series转换为NumPy数组
y_test_np = y_test.values  # 将Pandas Series转换为NumPy数组

# 数据预处理
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

X_train_tensor = torch.tensor(X_train_scaled, dtype=torch.float32).to(device)
X_test_tensor = torch.tensor(X_test_scaled, dtype=torch.float32).to(device)

# 使用模型进行预测
with torch.no_grad():
    # 获取训练集和测试集的预测结果
    y_train_pred_tensor = model(X_train_tensor)
    y_test_pred_tensor = model(X_test_tensor)

    y_train_pred = y_train_pred_tensor.cpu().numpy()
    y_test_pred = y_test_pred_tensor.cpu().numpy()

# 确保 y_test 和 y_test_pred 是一维数组
y_test = y_test_np.flatten()
y_test_pred = y_test_pred.flatten()
y_train = y_train_np.flatten()
y_train_pred = y_train_pred.flatten()

# 计算均方误差（MSE）
train_mse = mean_squared_error(y_train, y_train_pred)
test_mse = mean_squared_error(y_test, y_test_pred)
print("训练集均方误差 (MSE): %.2f" % train_mse)
print("测试集均方误差 (MSE): %.2f" % test_mse)

# 计算决定系数（R²）
train_r2 = r2_score(y_train, y_train_pred)
test_r2 = r2_score(y_test, y_test_pred)
print("训练集决定系数 (R²): %.2f" % train_r2)
print("测试集决定系数 (R²): %.2f" % test_r2)

# 计算拟合直线的斜率和截距（测试集）
test_slope, test_intercept = np.polyfit(y_test, y_test_pred, 1)
# 计算拟合直线的斜率和截距（训练集）
train_slope, train_intercept = np.polyfit(y_train, y_train_pred, 1)

# 计算置信区间和预测区间
def get_confidence_prediction_bands(y_true, y_pred, confidence=0.95):
    n = len(y_true)
    se = np.sqrt(np.sum((y_true - y_pred) ** 2) / (n - 2))
    t_value = 1.96  # for 95% confidence interval

    pred_band = t_value * se * np.sqrt(1 + 1/n)
    conf_band = t_value * se * np.sqrt(1 / n)

    return conf_band, pred_band

test_conf_band, test_pred_band = get_confidence_prediction_bands(y_test, y_test_pred)
train_conf_band, train_pred_band = get_confidence_prediction_bands(y_train, y_train_pred)

# 绘制测试集的拟合图像
plt.figure(figsize=(8, 6))
ax = plt.gca()
ax.spines['bottom'].set_linewidth(1)
ax.spines['left'].set_linewidth(1)
ax.spines['right'].set_linewidth(1)
ax.spines['top'].set_linewidth(1)

# 设置横坐标的长度（范围）
plt.xlim(y_test.min() - 0.2, y_test.max())

plt.plot([y_test.min(), y_test.max()],
         [test_slope*y_test.min()+test_intercept, test_slope*y_test.max()+test_intercept],
         color='black',
         linestyle='dashdot',
         linewidth=1.5,
         alpha=0.6,
         label='Linear Fit')

plt.scatter(y_test_pred, y_test, color='#0051ff', marker='o', alpha=0.9, label='Test Data Set', edgecolor='black', s=70, linewidth=0.5)

# 绘制95%置信区间
plt.fill_between([y_test.min(), y_test.max()],
                 [test_slope*y_test.min()+test_intercept-test_conf_band, test_slope*y_test.max()+test_intercept-test_conf_band],
                 [test_slope*y_test.min()+test_intercept+test_conf_band, test_slope*y_test.max()+test_intercept+test_conf_band],
                 color='darkgray',
                 alpha=0.5,
                 label='95% Confidence Band')

# 绘制95%预测区间
plt.fill_between([y_test.min(), y_test.max()],
                 [test_slope*y_test.min()+test_intercept-test_pred_band, test_slope*y_test.max()+test_intercept-test_pred_band],
                 [test_slope*y_test.min()+test_intercept+test_pred_band, test_slope*y_test.max()+test_intercept+test_pred_band],
                 color='lightgray',
                 alpha=0.5,
                 label='95% Prediction Band')

# plt.xlabel(r'Predicted $q_e$ (mg/g)', fontsize=20, fontweight='bold', color='black', fontname='Arial')
plt.xlabel('Predicted qₑ (mg/g)', fontsize=22, fontweight='bold', color='black', fontname='Arial')  #设置横纵坐标标签
plt.ylabel('Actual qₑ (mg/g)', fontsize=22, fontweight='bold', color='black', fontname='Arial')
#plt.title('Test Data: True vs. Predicted values', fontsize=22, fontweight='bold', color='black', fontname='Arial')
plt.xticks(fontsize=20, fontweight='bold', fontname='Arial', color='black')   #设置横纵坐标数值标签
plt.yticks(fontsize=20, fontweight='bold', fontname='Arial', color='black')
# 设置坐标轴短线的开口方向为向内
plt.tick_params(axis='both', direction='in', length=3)

# 调整图例的位置和字体
plt.legend(loc='upper left', frameon=False, prop={'weight': 'bold', 'size': 19, 'family': 'Arial'})

#添加文本
plt.text(0.66, 0.02, f'Fitting equation:\ny = {test_slope:.2f}x + {test_intercept:.2f}\nR$^2$: {test_r2:.2f}',
         fontsize=21, color='black', ha='left', va='bottom', fontname='Arial', fontweight='bold',transform=ax.transAxes)

# 去掉网格
plt.grid(False)

plt.tight_layout()

# 保存测试集拟合图像
#plt.savefig('C:/class/result/model-pre-result//CNN-test_fit.png', dpi=600)
plt.show()

#####-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 绘制训练集的拟合图像
plt.figure(figsize=(8, 6))
ax = plt.gca()
ax.spines['bottom'].set_linewidth(1)
ax.spines['left'].set_linewidth(1)
ax.spines['right'].set_linewidth(1)
ax.spines['top'].set_linewidth(1)

# 设置横坐标的长度（范围）
plt.xlim(y_train.min() - 0.2, y_train.max())

plt.plot([y_train.min(), y_train.max()],
         [train_slope*y_train.min()+train_intercept, train_slope*y_train.max()+train_intercept],
         color='black',
         linestyle='dashdot',
         linewidth=1.5,
         alpha=0.6,
         label='Linear Fit')

plt.scatter(y_train_pred, y_train, color='#ff602b', marker='o', alpha=0.9, label='Train Data Set', edgecolor='black', s=70, linewidth=0.5)

# 绘制95%置信区间
plt.fill_between([y_train.min(), y_train.max()],
                 [train_slope*y_train.min()+train_intercept-train_conf_band, train_slope*y_train.max()+train_intercept-train_conf_band],
                 [train_slope*y_train.min()+train_intercept+train_conf_band, train_slope*y_train.max()+train_intercept+train_conf_band],
                 color='darkgray',
                 alpha=0.5,
                 label='95% Confidence Band')

# 绘制95%预测区间
plt.fill_between([y_train.min(), y_train.max()],
                 [train_slope*y_train.min()+train_intercept-train_pred_band, train_slope*y_train.max()+train_intercept-train_pred_band],
                 [train_slope*y_train.min()+train_intercept+train_pred_band, train_slope*y_train.max()+train_intercept+train_pred_band],
                 color='lightgray',
                 alpha=0.3,
                 label='95% Prediction Band')

plt.xlabel('Predicted qₑ (mg/g)', fontsize=22, fontweight='bold', fontname='Arial')
plt.ylabel('Actual qₑ (mg/g)', fontsize=22, fontweight='bold', fontname='Arial')
#plt.title('Train Data: True vs. Predicted values', fontsize=24, fontweight='bold', fontname='Arial')
plt.xticks(fontsize=20, fontweight='bold', fontname='Arial', color='black')
plt.yticks(fontsize=20, fontweight='bold', fontname='Arial', color='black')
plt.tick_params(axis='both', direction='in', length=3)

# 调整图例的位置和字体
plt.legend(loc='upper left', frameon=False, prop={'weight': 'bold', 'size': 19, 'family': 'Arial'})

# 添加文本
plt.text(0.66, 0.02, f'Fitting equation:\ny = {train_slope:.2f}x + {train_intercept:.2f}\nR$^2$: {train_r2:.2f}',
         fontsize=21, color='black', ha='left', va='bottom', fontname='Arial', fontweight='bold', transform=ax.transAxes)

plt.grid(False)
plt.tight_layout()

# 保存训练集拟合图像
#plt.savefig('C:/class/result/model-pre-result/123/CNN-train_fit.png', dpi=600)
plt.show()
"""
#PCA （最新）《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, Flatten, Dense
from sklearn.decomposition import PCA

# ------------------ 数据读取 ------------------
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# ------------------ 新增：对C和F做PCA --------------------------------------
# 假设数据集中存在 'C' 和 'F' 两列
cf_features = data[['C', 'F']]

# 标准化
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

# PCA，降到1个主成分（或者2个，你可以改 n_components=2）
pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

# 将 PCA 结果替换原始 C、F 特征
data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca



# ------------------ 检查数据是否有 NaN ------------------
if data.isna().any().any():
    print("数据中存在 NaN，进行填充为均值")
    data = data.fillna(data.mean())

# ------------------ 提取自变量和因变量 ------------------
X = data.iloc[:, :-1].values  # 自变量
y = data.iloc[:, -1].values   # 因变量

# ------------------ 数据标准化 ------------------
scaler_X = StandardScaler()
scaler_y = StandardScaler()

X = scaler_X.fit_transform(X)
y = scaler_y.fit_transform(y.reshape(-1, 1)).ravel()

# ------------------ 划分训练集和测试集 ------------------
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=41)

# ------------------ 调整输入形状适应 CNN ------------------
X_train = np.expand_dims(X_train, axis=2)
X_test = np.expand_dims(X_test, axis=2)

# ------------------ 构建 CNN 模型 ------------------
model = Sequential()
model.add(Conv1D(filters=32, kernel_size=3, activation='relu', input_shape=(X_train.shape[1], 1)))
model.add(Flatten())
model.add(Dense(64, activation='relu'))
model.add(Dense(1))  # 输出层

# ------------------ 编译模型 ------------------
model.compile(optimizer='adam', loss='mse', metrics=['mse'])

# ------------------ 训练模型 ------------------
model.fit(X_train, y_train, epochs=50, batch_size=32, verbose=1)

# ------------------ 预测 ------------------
y_pred_test_scaled = model.predict(X_test).flatten()
y_pred_test = scaler_y.inverse_transform(y_pred_test_scaled.reshape(-1, 1)).ravel()
y_test_true = scaler_y.inverse_transform(y_test.reshape(-1, 1)).ravel()

y_pred_train_scaled = model.predict(X_train).flatten()
y_pred_train = scaler_y.inverse_transform(y_pred_train_scaled.reshape(-1, 1)).ravel()
y_train_true = scaler_y.inverse_transform(y_train.reshape(-1, 1)).ravel()

# ------------------ 评价指标 ------------------
test_mse = mean_squared_error(y_test_true, y_pred_test)
test_r2 = r2_score(y_test_true, y_pred_test)
train_mse = mean_squared_error(y_train_true, y_pred_train)
train_r2 = r2_score(y_train_true, y_pred_train)

print(f"测试集 MSE: {test_mse:.2f}, R²: {test_r2:.2f}")
print(f"训练集 MSE: {train_mse:.2f}, R²: {train_r2:.2f}")

# ------------------ 拟合直线 ------------------
test_slope, test_intercept = np.polyfit(y_test_true, y_pred_test, 1)
train_slope, train_intercept = np.polyfit(y_train_true, y_pred_train, 1)

# ------------------ 置信区间和预测区间函数 ------------------
def get_confidence_prediction_bands(y_true, y_pred, confidence=0.95):
    n = len(y_true)
    se = np.sqrt(np.sum((y_true - y_pred) ** 2) / (n - 2))
    t_value = 1.96  # 95%置信区间
    pred_band = t_value * se * np.sqrt(1 + 1/n)
    conf_band = t_value * se * np.sqrt(1 / n)
    return conf_band, pred_band

test_conf_band, test_pred_band = get_confidence_prediction_bands(y_test_true, y_pred_test)
train_conf_band, train_pred_band = get_confidence_prediction_bands(y_train_true, y_pred_train)

# ------------------ 绘制测试集拟合图 ------------------
plt.figure(figsize=(8, 6))
ax = plt.gca()
plt.xlim(y_test_true.min() - 0.2, y_test_true.max())
plt.plot([y_test_true.min(), y_test_true.max()],
         [test_slope*y_test_true.min()+test_intercept, test_slope*y_test_true.max()+test_intercept],
         color='black', linestyle='dashdot', linewidth=1.5, alpha=0.6, label='Linear Fit')
plt.scatter(y_test_true, y_pred_test, color='#0051ff', marker='o', alpha=0.9, label='Testing Data', edgecolor='black', s=70, linewidth=0.5)
plt.fill_between([y_test_true.min(), y_test_true.max()],
                 [test_slope*y_test_true.min()+test_intercept-test_conf_band, test_slope*y_test_true.max()+test_intercept-test_conf_band],
                 [test_slope*y_test_true.min()+test_intercept+test_conf_band, test_slope*y_test_true.max()+test_intercept+test_conf_band],
                 color='darkgray', alpha=0.5, label='95% Confidence Band')
plt.fill_between([y_test_true.min(), y_test_true.max()],
                 [test_slope*y_test_true.min()+test_intercept-test_pred_band, test_slope*y_test_true.max()+test_intercept-test_pred_band],
                 [test_slope*y_test_true.min()+test_intercept+test_pred_band, test_slope*y_test_true.max()+test_intercept+test_pred_band],
                 color='lightgray', alpha=0.3, label='95% Prediction Band')
plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontname='Arial')
plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontname='Arial')
plt.xticks(fontsize=30, fontname='Arial')
plt.yticks(fontsize=30, fontname='Arial')
plt.tick_params(axis='both', direction='in', length=3)
plt.legend(loc='upper left', frameon=False, prop={'size': 22, 'family': 'Arial'})
plt.text(0.62, 0.02, f'Fitting equation:\ny = {test_slope:.2f}x + {test_intercept:.2f}\nR²: {test_r2:.2f}',
         fontsize=25, color='black', ha='left', va='bottom', transform=ax.transAxes)
plt.grid(False)
plt.tight_layout()
# 保存测试集图像
plt.savefig(r'D:\PyCharm\Py_Project\PFAS\123\CNN_test_fit.png', dpi=600)
plt.show()

# ------------------ 绘制训练集拟合图 ------------------
plt.figure(figsize=(8, 6))
ax = plt.gca()
plt.xlim(y_train_true.min() - 0.2, y_train_true.max())
plt.plot([y_train_true.min(), y_train_true.max()],
         [train_slope*y_train_true.min()+train_intercept, train_slope*y_train_true.max()+train_intercept],
         color='black', linestyle='dashdot', linewidth=1.5, alpha=0.6, label='Linear Fit')
plt.scatter(y_train_true, y_pred_train, color='#ff602b', marker='o', alpha=0.9, label='Training Data', edgecolor='black', s=70, linewidth=0.5)
plt.fill_between([y_train_true.min(), y_train_true.max()],
                 [train_slope*y_train_true.min()+train_intercept-train_conf_band, train_slope*y_train_true.max()+train_intercept-train_conf_band],
                 [train_slope*y_train_true.min()+train_intercept+train_conf_band, train_slope*y_train_true.max()+train_intercept+train_conf_band],
                 color='darkgray', alpha=0.5, label='95% Confidence Band')
plt.fill_between([y_train_true.min(), y_train_true.max()],
                 [train_slope*y_train_true.min()+train_intercept-train_pred_band, train_slope*y_train_true.max()+train_intercept-train_pred_band],
                 [train_slope*y_train_true.min()+train_intercept+train_pred_band, train_slope*y_train_true.max()+train_intercept+train_pred_band],
                 color='lightgray', alpha=0.3, label='95% Prediction Band')
plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontname='Arial')
plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontname='Arial')
plt.xticks(fontsize=30, fontname='Arial')
plt.yticks(fontsize=30, fontname='Arial')
plt.tick_params(axis='both', direction='in', length=3)
plt.legend(loc='upper left', frameon=False, prop={'size': 22, 'family': 'Arial'})
plt.text(0.62, 0.02, f'Fitting equation:\ny = {train_slope:.2f}x + {train_intercept:.2f}\nR²: {train_r2:.2f}',
         fontsize=25, color='black', ha='left', va='bottom', transform=ax.transAxes)
plt.grid(False)
plt.tight_layout()
# 保存训练集图像
plt.savefig(r'D:\PyCharm\Py_Project\PFAS\123\CNN_train_fit.png', dpi=600)
plt.show()
