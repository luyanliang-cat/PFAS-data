"""
import pandas as pd
import seaborn as sns  # 统一使用 sns 别名
import matplotlib.pyplot as plt
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant
from sklearn.impute import SimpleImputer

# ======================
# 1. 数据加载
# ======================
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

X = data.iloc[:, :-1]  # 提取所有自变量（特征）

# 创建并应用SimpleImputer
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 转换为 DataFrame 恢复列名
X_df = pd.DataFrame(X, columns=data.columns[:-1])

# ======================
# 2. 处理常数项（必须步骤）
# ======================
X_with_constant = add_constant(X_df)  # 添加常数项（截距）
# ======================
# 3. 计算VIF
# ======================
vif_data = pd.DataFrame()
vif_data["Feature"] = X_with_constant.columns  # 特征名称（包含常数项）

# 计算每个特征的VIF
vif_data["VIF"] = [
    variance_inflation_factor(X_with_constant.values, i)
    for i in range(X_with_constant.shape[1])
]

# 排除常数项的VIF（通常极高，无需分析）
vif_data = vif_data[vif_data["Feature"] != "const"]  # 移除常数项
vif_data = vif_data.sort_values(by="VIF", ascending=False)  # 按VIF降序排列

# ======================
# 4. 结果打印
# ======================
print("方差膨胀因子（VIF）计算结果：")
print(vif_data)

# ======================
# 5. 可视化：VIF条形图
# ======================
plt.figure(figsize=(9, 6))  # 设置画布尺寸

# 绘制条形图（使用 sns 别名）
ax = sns.barplot(
    x="VIF",
    y="Feature",
    data=vif_data,
    palette="plasma",  # 使用与原代码一致的颜色方案
    orient="h"  # 水平条形图更适合特征名称较长的情况
)

# 添加数值标签
for i, vif in enumerate(vif_data["VIF"]):
    ax.text(vif + 0.5, i, f"{vif:.2f}", va="center", fontsize=12, fontname="Arial")

# 坐标轴设置
plt.xlabel("Variance Inflation Factor (VIF)", fontsize=16, fontname="Arial")
plt.ylabel("Features", fontsize=16, fontname="Arial")

# 刻度设置
plt.xticks(fontsize=14, fontname="Arial")
plt.yticks(fontsize=14, fontname="Arial")

# 网格线
plt.grid(axis="x", linestyle="--", alpha=0.7)

# 标题（可选）
plt.title("Feature Multicollinearity (VIF)", fontsize=18, fontname="Arial", pad=20)

# 布局优化
plt.tight_layout()

# 保存和显示
plt.savefig("D:/PyCharm/Py_Project/PFAS/fig/VIF_analysis_new.png", dpi=300, bbox_inches="tight")
plt.show()

# ======================
# 6. 共线性严重程度标注（控制台输出）
# ======================
print("\n共线性严重程度判断：")
for idx, row in vif_data.iterrows():
    vif = row["VIF"]
    if vif < 5:
        severity = "无严重共线性"
    elif 5 <= vif < 10:
        severity = "中等共线性"
    else:
        severity = "严重共线性"
    print(f"{row['Feature']}: VIF={vif:.2f} → {severity}")
"""

#PCA一下C和F《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.tools.tools import add_constant
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# ======================
# 1. 数据加载
# ======================
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# 批量替换指定列名
data.rename(columns=lambda x: x.replace("BET(m2/g)", "BET (m²/g)"), inplace=True)

X = data.iloc[:, :-1]  # 提取所有自变量

# 缺失值处理
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)

# 转换为 DataFrame
X_df = pd.DataFrame(X_imputed, columns=data.columns[:-1])

# ======================
# 2. PCA 压缩 C 和 F
# ======================
cf_data = X_df[['C', 'F']]
scaler = StandardScaler()
cf_scaled = scaler.fit_transform(cf_data)

pca = PCA(n_components=1)
X_df['C_F_PC'] = pca.fit_transform(cf_scaled)

# 删除原始的 C 和 F
X_df.drop(['C', 'F'], axis=1, inplace=True)

print(f"✅ C_F_PC 第一主成分解释的方差比例: {pca.explained_variance_ratio_[0]:.4f}")

# ======================
# 3. 处理常数项（必须步骤）
# ======================
X_with_constant = add_constant(X_df)

# ======================
# 4. 计算 VIF
# ======================
vif_data = pd.DataFrame()
vif_data["Feature"] = X_with_constant.columns

vif_data["VIF"] = [
    variance_inflation_factor(X_with_constant.values, i)
    for i in range(X_with_constant.shape[1])
]

# 移除常数项
vif_data = vif_data[vif_data["Feature"] != "const"]
vif_data = vif_data.sort_values(by="VIF", ascending=False)

print("方差膨胀因子（VIF）计算结果：")
print(vif_data)

# ======================
# 5. 可视化 VIF 条形图
# ======================
plt.figure(figsize=(9, 6))
ax = sns.barplot(
    x="VIF",
    y="Feature",
    data=vif_data,
    palette="plasma",
    orient="h"
)

# 获取横坐标范围
xmax = ax.get_xlim()[1]

for i, vif in enumerate(vif_data["VIF"]):
    ax.text(vif + 0.1, i, f"{vif:.2f}", va="center",  ha="right", fontsize=12, fontname="Microsoft YaHei")

plt.xlabel("Variance Inflation Factor (VIF)", fontsize=16, fontname="Microsoft YaHei")
plt.ylabel("Features", fontsize=16, fontname="Microsoft YaHei")
plt.xticks(fontsize=14, fontname="Microsoft YaHei")
plt.yticks(fontsize=14, fontname="Microsoft YaHei")
#plt.grid(axis="x", linestyle="--", alpha=0.7)
plt.title("Feature Multicollinearity", fontsize=18, fontname="Microsoft YaHei", pad=20)
plt.tight_layout()
plt.savefig("D:/PyCharm/Py_Project/PFAS/fig/VIF_analysis_PCA_CF.png", dpi=300, bbox_inches="tight")
plt.show()

# ======================
# 6. 共线性严重程度输出
# ======================
print("\n共线性严重程度判断：")
for idx, row in vif_data.iterrows():
    vif = row["VIF"]
    if vif < 5:
        severity = "无严重共线性"
    elif 5 <= vif < 10:
        severity = "中等共线性"
    else:
        severity = "严重共线性"
    print(f"{row['Feature']}: VIF={vif:.2f} → {severity}")
