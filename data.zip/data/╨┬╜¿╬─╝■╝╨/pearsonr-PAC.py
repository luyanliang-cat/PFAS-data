import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from scipy.stats import pearsonr
import os
plt.rcParams['font.family'] = 'DejaVu Sans'

# 数据路径
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
save_path = 'D:/PyCharm/Py_Project/PFAS/pearson'
os.makedirs(save_path, exist_ok=True)  # 创建保存目录

# 读取数据
data = pd.read_excel(file_path)

# 批量替换指定列名
data.rename(columns=lambda x: x.replace("BET(m2/g)", "BET (m²/g)"), inplace=True)
data.rename(columns=lambda x: x.replace("TPV(cm3/g)", "TPV (cm³/g)"), inplace=True)
# 提取自变量和因变量
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 缺失值处理
imputer = SimpleImputer(strategy='most_frequent')
X_imputed = imputer.fit_transform(X)

# 转为 DataFrame
data_imputed = pd.DataFrame(X_imputed, columns=X.columns)
data_imputed[data.columns[-1]] = y

# 替换 inf 并删除 NaN
data_imputed.replace([np.inf, -np.inf], np.nan, inplace=True)
data_imputed.dropna(inplace=True)

# ====== PCA 压缩 C 和 F ======
cf_data = data_imputed[['C', 'F']]
scaler = StandardScaler()
cf_scaled = scaler.fit_transform(cf_data)

pca = PCA(n_components=1)
cf_pc1 = pca.fit_transform(cf_scaled)

# 加入主成分
data_imputed['C_F_PC'] = cf_pc1

# 删除原来的 C 和 F
data_imputed.drop(['C', 'F'], axis=1, inplace=True)

# 输出主成分解释的方差比例
explained_variance = pca.explained_variance_ratio_[0]
print(f"第一主成分解释的方差比例: {explained_variance:.4f}")

# ====== 计算 Pearson 相关系数 ======
corr_matrix = data_imputed.corr()

# 输出每对自变量的 Pearson 系数和 p 值
for col1 in corr_matrix.columns:
    for col2 in corr_matrix.columns:
        if col1 != col2:
            corr, p_value = pearsonr(data_imputed[col1], data_imputed[col2])
            print(f'自变量 {col1} 和 {col2} 的 Pearson 相关系数：{corr:.2f} (p-value: {p_value:.3f})')


plt.rcParams['font.family'] = 'Microsoft YaHei'  # 支持中文和℃
plt.rcParams['axes.unicode_minus'] = False       # 负号正常显示


# ====== 绘制热力图 ======
plt.figure(figsize=(16, 12))
"""
sns.heatmap(
    data=corr_matrix.round(2), cmap="YlGnBu", annot=True, linewidths=0.5,
    annot_kws={"fontsize": 10, "fontname": "Microsoft YaHei", "fontweight": "bold"},
    cbar_kws={"orientation": "vertical", "shrink": 0.9, "pad": 0.01, "extend": "both"},
    square=True
)
plt.title("Pearson's correlation coefficient of features after PCA", fontsize=18, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontsize=12, fontname='Arial', weight='bold')
plt.yticks(rotation=45, fontsize=12, fontname='Arial', weight='bold')
plt.tight_layout()
"""
ax = sns.heatmap(
    data=corr_matrix.round(2),
    cmap="YlGnBu",
    annot=True,
    linewidths=0.5,
    annot_kws={"fontsize": 18, "fontname": "Microsoft YaHei", "fontweight": "bold"},  # <-- 注释字体
    cbar_kws={"orientation": "vertical", "shrink": 0.9, "pad": 0.01, "extend": "both"},
    square=True
)
#plt.title("Pearson's correlation coefficient of features after PCA", fontsize=22, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontsize=20, fontname='Microsoft YaHei', weight='bold')
plt.yticks(rotation=45, fontsize=20, fontname='Microsoft YaHei', weight='bold')
# 调整 colorbar 字体大小
cbar = ax.collections[0].colorbar
cbar.ax.tick_params(labelsize=18)  # 修改右侧 colorbar 的字体大小
plt.tight_layout()


# 保存图像
out_file = os.path.join(save_path, "pearson_correlation_heatmap_PCA-CF012.png")
plt.savefig(out_file, dpi=300, bbox_inches='tight')
plt.close()

print(f"✅ 热力图已保存到: {out_file}")
