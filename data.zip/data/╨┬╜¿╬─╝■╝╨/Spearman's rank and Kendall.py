"""
import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import spearmanr, kendalltau
from matplotlib import font_manager as fm
from mpl_toolkits.axes_grid1 import make_axes_locatable

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-new-ppppp.xlsx'
data = pd.read_excel(file_path)


# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 将所有列转换为数值类型，无法转换的会变为NaN
df = data.apply(pd.to_numeric, errors='coerce')

# 计算所有自变量之间的斯皮尔曼等级相关系数
spearman_corr_matrix = df.corr(method='spearman')

# 逐一计算每对自变量之间的斯皮尔曼等级相关系数并输出结果
for col1 in spearman_corr_matrix.columns:
    for col2 in spearman_corr_matrix.columns:
        if col1 != col2:
            corr, p_value = spearmanr(df[col1], df[col2])
            # print(f'自变量 {col1} 和 {col2} 之间的斯皮尔曼等级相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制斯皮尔曼等级相关系数的热力图
plt.figure(figsize=(9, 8))
ax = sns.heatmap(data=spearman_corr_matrix.round(2),
                 cmap="plasma",  # YlGnBu，viridis
                 annot=True,
                 linewidths=0,
                 annot_kws={"fontsize": 12, "fontname": "Arial", "fontweight": "normal"},
                 cbar_kws={"orientation": "vertical", "shrink": 1.0, "pad": 0.03, "extend": "neither"},
                 square=True)

# 手动设置 x 轴刻度标签
x_labels = spearman_corr_matrix.columns.tolist()
x_ticks = np.arange(len(x_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_xticks(x_ticks)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 手动设置 y 轴刻度标签
y_labels = spearman_corr_matrix.columns.tolist()
y_ticks = np.arange(len(y_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_yticks(y_ticks)
ax.set_yticklabels(y_labels, rotation=45, va='center', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 设置标签与轴的距离
ax.xaxis.labelpad = 2  # 调整横坐标标签与轴的距离
ax.yaxis.labelpad = 2  # 调整纵坐标标签与轴的距离

plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/Spearman.tif', format="tiff", dpi=300)
plt.show()

# 计算所有自变量之间的肯德尔等级相关系数
kendall_corr_matrix = df.corr(method='kendall')

# 逐一计算每对自变量之间的肯德尔等级相关系数并输出结果
for col1 in kendall_corr_matrix.columns:
    for col2 in kendall_corr_matrix.columns:
        if col1 != col2:
            corr, p_value = kendalltau(df[col1], df[col2])
            # print(f'自变量 {col1} 和 {col2} 之间的肯德尔等级相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制肯德尔等级相关系数的热力图
plt.figure(figsize=(9, 8))
ax = sns.heatmap(data=kendall_corr_matrix.round(2),
                 cmap="plasma",  # YlGnBu，viridis
                 annot=True,
                 linewidths=0,
                 annot_kws={"fontsize": 12, "fontname": "Arial", "fontweight": "normal"},
                 cbar_kws={"orientation": "vertical", "shrink": 1.0, "pad": 0.03, "extend": "neither"},
                 square=True)

# 手动设置 x 轴刻度标签
x_labels = kendall_corr_matrix.columns.tolist()
x_ticks = np.arange(len(x_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_xticks(x_ticks)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 手动设置 y 轴刻度标签
y_labels = kendall_corr_matrix.columns.tolist()
y_ticks = np.arange(len(y_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_yticks(y_ticks)
ax.set_yticklabels(y_labels, rotation=45, va='center', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 设置标签与轴的距离
ax.xaxis.labelpad = 2  # 调整横坐标标签与轴的距离
ax.yaxis.labelpad = 2  # 调整纵坐标标签与轴的距离

plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/Kendall.tif', format="tiff", dpi=300)
plt.show()


# 提取自变量和因变量
X = df.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = df.iloc[:, -1]  # 因变量，选择最后一列

# 将所有列转换为数值类型，无法转换的会变为NaN
df = df.apply(pd.to_numeric, errors='coerce')

# 计算所有自变量之间的斯皮尔曼等级相关系数
spearman_corr_matrix = df.corr(method='spearman')

# 逐一计算每对自变量之间的斯皮尔曼等级相关系数并输出结果
for col1 in spearman_corr_matrix.columns:
    for col2 in spearman_corr_matrix.columns:
        if col1 != col2:
            corr, p_value = spearmanr(df[col1], df[col2])
            # print(f'自变量 {col1} 和 {col2} 之间的斯皮尔曼等级相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制斯皮尔曼等级相关系数的热力图
plt.figure(figsize=(9, 8))
ax = sns.heatmap(data=spearman_corr_matrix.round(2),
                 cmap="plasma",  # YlGnBu，viridis
                 annot=True,
                 linewidths=0,
                 annot_kws={"fontsize": 12, "fontname": "Arial", "fontweight": "normal"},
                 cbar_kws={"orientation": "vertical", "shrink": 1.0, "pad": 0.03, "extend": "neither"},
                 square=True)

# 手动设置 x 轴刻度标签
x_labels = spearman_corr_matrix.columns.tolist()
x_ticks = np.arange(len(x_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_xticks(x_ticks)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 手动设置 y 轴刻度标签
y_labels = spearman_corr_matrix.columns.tolist()
y_ticks = np.arange(len(y_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_yticks(y_ticks)
ax.set_yticklabels(y_labels, rotation=45, va='center', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 设置标签与轴的距离
ax.xaxis.labelpad = 2  # 调整横坐标标签与轴的距离
ax.yaxis.labelpad = 2  # 调整纵坐标标签与轴的距离

plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/Spearman.tif', format="tiff", dpi=300)
plt.show()

# 计算所有自变量之间的肯德尔等级相关系数
kendall_corr_matrix = df.corr(method='kendall')

# 逐一计算每对自变量之间的肯德尔等级相关系数并输出结果
for col1 in kendall_corr_matrix.columns:
    for col2 in kendall_corr_matrix.columns:
        if col1 != col2:
            corr, p_value = kendalltau(df[col1], df[col2])
            # print(f'自变量 {col1} 和 {col2} 之间的肯德尔等级相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制肯德尔等级相关系数的热力图
plt.figure(figsize=(9, 8))
ax = sns.heatmap(data=kendall_corr_matrix.round(2),
                 cmap="plasma",  # YlGnBu，viridis
                 annot=True,
                 linewidths=0,
                 annot_kws={"fontsize": 12, "fontname": "Arial", "fontweight": "normal"},
                 cbar_kws={"orientation": "vertical", "shrink": 1.0, "pad": 0.03, "extend": "neither"},
                 square=True)

# 手动设置 x 轴刻度标签
x_labels = kendall_corr_matrix.columns.tolist()
x_ticks = np.arange(len(x_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_xticks(x_ticks)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 手动设置 y 轴刻度标签
y_labels = kendall_corr_matrix.columns.tolist()
y_ticks = np.arange(len(y_labels)) + 0.5  # 将刻度位置调整到单元格中心
ax.set_yticks(y_ticks)
ax.set_yticklabels(y_labels, rotation=45, va='center', fontsize=17, fontname='Arial', weight='normal',
                   rotation_mode='anchor')

# 设置标签与轴的距离
ax.xaxis.labelpad = 2  # 调整横坐标标签与轴的距离
ax.yaxis.labelpad = 2  # 调整纵坐标标签与轴的距离

plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/Kendall.tif', format="tiff", dpi=300)
plt.show()
"""

import pandas as pd
import seaborn as sns
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import spearmanr, kendalltau
from sklearn.decomposition import PCA

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)


# 批量替换指定列名
data.rename(columns=lambda x: x.replace("BET(m2/g)", "BET (m²/g)"), inplace=True)

# 将所有列转换为数值类型，无法转换的会变为NaN
df = data.apply(pd.to_numeric, errors='coerce')

# -------------------------------
# 1. 对 C 和 F 做 PCA 压缩
# -------------------------------
if 'C' in df.columns and 'F' in df.columns:
    pca = PCA(n_components=1)  # 取一个主成分
    cf_pc = pca.fit_transform(df[['C', 'F']].dropna())
    df['C_F_PC'] = np.nan
    df.loc[df[['C', 'F']].dropna().index, 'C_F_PC'] = cf_pc  # 保证索引对齐

    # 删除原始的 C 和 F，避免重复
    df = df.drop(columns=['C', 'F'])
else:
    raise ValueError("列名中未找到 C 和 F，请检查 Excel 文件")

# -------------------------------
# 2. 计算 Spearman 相关系数矩阵
# -------------------------------
spearman_corr_matrix = df.corr(method='spearman')

plt.figure(figsize=(9, 8))
ax = sns.heatmap(data=spearman_corr_matrix.round(2),
                 cmap="plasma",
                 annot=True,
                 linewidths=0,
                 annot_kws={"fontsize": 12, "fontname": "Arial"},
                 cbar_kws={"orientation": "vertical", "shrink": 1.0, "pad": 0.03},
                 square=True)

# 设置坐标轴标签
x_labels = spearman_corr_matrix.columns.tolist()
ax.set_xticks(np.arange(len(x_labels)) + 0.5)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=17, fontname='Microsoft YaHei')

y_labels = spearman_corr_matrix.columns.tolist()
ax.set_yticks(np.arange(len(y_labels)) + 0.5)
ax.set_yticklabels(y_labels, rotation=45, va='center', fontsize=17, fontname='Microsoft YaHei')

plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/Spearman_PCA.tif', format="tiff", dpi=300)
plt.show()

# -------------------------------
# 3. 计算 Kendall 相关系数矩阵
# -------------------------------
kendall_corr_matrix = df.corr(method='kendall')

plt.figure(figsize=(9, 8))
ax = sns.heatmap(data=kendall_corr_matrix.round(2),
                 cmap="plasma",
                 annot=True,
                 linewidths=0,
                 annot_kws={"fontsize": 12, "fontname": "Arial"},
                 cbar_kws={"orientation": "vertical", "shrink": 1.0, "pad": 0.03},
                 square=True)

# 设置坐标轴标签
x_labels = kendall_corr_matrix.columns.tolist()
ax.set_xticks(np.arange(len(x_labels)) + 0.5)
ax.set_xticklabels(x_labels, rotation=45, ha='right', fontsize=17, fontname='Microsoft YaHei')

y_labels = kendall_corr_matrix.columns.tolist()
ax.set_yticks(np.arange(len(y_labels)) + 0.5)
ax.set_yticklabels(y_labels, rotation=45, va='center', fontsize=17, fontname='Microsoft YaHei')

plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/Kendall_PCA.tif', format="tiff", dpi=300)
plt.show()
