"""
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, r2_score

# 定义 Transformer 模型（新结构）
class TransformerRegressor(nn.Module):
    def __init__(self, input_dim, output_dim=1, nhead=1, num_layers=2, dim_feedforward=128, dropout=0.1):
        super(TransformerRegressor, self).__init__()
        self.embedding = nn.Linear(input_dim, input_dim)
        encoder_layer = nn.TransformerEncoderLayer(d_model=input_dim, nhead=nhead,
                                                   dim_feedforward=dim_feedforward, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.output_layer = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        x = self.embedding(x)
        x = self.transformer_encoder(x)
        x = x.mean(dim=0)  # 平均池化
        out = self.output_layer(x)
        return out.squeeze()

# 读取数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-new-ppppp.xlsx'
data = pd.read_excel(file_path)

# 拆分自变量和因变量
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 缺失值填充
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 数据标准化
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为Tensor（注意形状）
X_train_tensor = torch.tensor(X_train, dtype=torch.float32).unsqueeze(1).transpose(0, 1)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32).unsqueeze(1).transpose(0, 1)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32)

# 初始化模型参数
input_dim = X_train.shape[1]
model = TransformerRegressor(input_dim=input_dim)

# 损失函数与优化器
loss_fn = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 模型训练
epochs = 200
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    output = model(X_train_tensor)
    loss = loss_fn(output, y_train_tensor)
    loss.backward()
    optimizer.step()

    if (epoch + 1) % 20 == 0:
        print(f"Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")

# 保存模型
torch.save(model.state_dict(), "Transformer_model_new.pth")
print("✅ 模型保存成功：Transformer_model_new.pth")

# 模型评估
model.eval()
with torch.no_grad():
    y_train_pred = model(X_train_tensor).cpu().numpy()
    y_test_pred  = model(X_test_tensor).cpu().numpy()

# 检查 NaN
if np.isnan(y_train_pred).any():
    raise ValueError("训练集预测结果中存在 NaN 值，请检查模型输出")
if np.isnan(y_test_pred).any():
    raise ValueError("测试集预测结果中存在 NaN 值，请检查模型输出")

# MSE 和 R²
train_mse = mean_squared_error(y_train, y_train_pred)
test_mse = mean_squared_error(y_test, y_test_pred)
train_r2 = r2_score(y_train, y_train_pred)
test_r2 = r2_score(y_test, y_test_pred)

print(f"训练集 MSE: {train_mse:.4f}, R²: {train_r2:.4f}")
print(f"测试集 MSE: {test_mse:.4f}, R²: {test_r2:.4f}")
"""


"""
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.decomposition import PCA


# 定义 Transformer 模型（新结构）
class TransformerRegressor(nn.Module):
    def __init__(self, input_dim, output_dim=1, nhead=1, num_layers=2, dim_feedforward=128, dropout=0.1):
        super(TransformerRegressor, self).__init__()
        self.embedding = nn.Linear(input_dim, input_dim)
        encoder_layer = nn.TransformerEncoderLayer(d_model=input_dim, nhead=nhead,
                                                   dim_feedforward=dim_feedforward, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.output_layer = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        x = self.embedding(x)
        x = self.transformer_encoder(x)
        x = x.mean(dim=0)  # 平均池化
        out = self.output_layer(x)
        return out.squeeze()

# 读取数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)


# ------------------ 新增：对C和F做PCA --------------------------------------
# 假设数据集中存在 'C' 和 'F' 两列
cf_features = data[['C', 'F']]

# 标准化
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

# PCA，降到1个主成分（或者2个，你可以改 n_components=2）
pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

# 将 PCA 结果替换原始 C、F 特征
data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca



# 拆分自变量和因变量
#X = data.iloc[:, :-1]
#y = data.iloc[:, -1]
X = data_pca.iloc[:, :-1]
y = data_pca.iloc[:, -1]


# 缺失值填充
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 数据标准化
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为Tensor（注意形状）
X_train_tensor = torch.tensor(X_train, dtype=torch.float32).unsqueeze(1).transpose(0, 1)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32).unsqueeze(1).transpose(0, 1)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32)

# 初始化模型参数
input_dim = X_train.shape[1]
model = TransformerRegressor(input_dim=input_dim)



# 损失函数与优化器
loss_fn = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 模型训练
epochs = 200
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    output = model(X_train_tensor)
    loss = loss_fn(output, y_train_tensor)
    loss.backward()
    optimizer.step()

    if (epoch + 1) % 20 == 0:
        print(f"Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")

# 保存模型
torch.save(model.state_dict(), "Transformer_model_new.pth")
print("✅ 模型保存成功：Transformer_model_new.pth")

# 模型评估
model.eval()
with torch.no_grad():
    y_train_pred = model(X_train_tensor).cpu().numpy()
    y_test_pred  = model(X_test_tensor).cpu().numpy()

# 检查 NaN
if np.isnan(y_train_pred).any():
    raise ValueError("训练集预测结果中存在 NaN 值，请检查模型输出")
if np.isnan(y_test_pred).any():
    raise ValueError("测试集预测结果中存在 NaN 值，请检查模型输出")

# MSE 和 R²
train_mse = mean_squared_error(y_train, y_train_pred)
test_mse = mean_squared_error(y_test, y_test_pred)
train_r2 = r2_score(y_train, y_train_pred)
test_r2 = r2_score(y_test, y_test_pred)

print(f"训练集 MSE: {train_mse:.4f}, R²: {train_r2:.4f}")
print(f"测试集 MSE: {test_mse:.4f}, R²: {test_r2:.4f}")
"""
#PCA（最新版本）《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《
import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt


# 定义 Transformer 模型（新结构）
class TransformerRegressor(nn.Module):
    def __init__(self, input_dim, output_dim=1, nhead=1, num_layers=2, dim_feedforward=128, dropout=0.1):
        super(TransformerRegressor, self).__init__()
        self.embedding = nn.Linear(input_dim, input_dim)
        encoder_layer = nn.TransformerEncoderLayer(d_model=input_dim, nhead=nhead,
                                                   dim_feedforward=dim_feedforward, dropout=dropout)
        self.transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.output_layer = nn.Linear(input_dim, output_dim)

    def forward(self, x):
        x = self.embedding(x)
        x = self.transformer_encoder(x)
        x = x.mean(dim=0)  # 平均池化
        out = self.output_layer(x)
        return out.squeeze()


# 读取数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# ------------------ 新增：对C和F做PCA --------------------------------------
cf_features = data[['C', 'F']]
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca

# 拆分自变量和因变量
X = data.iloc[:, :-1]
y = data.iloc[:, -1]

# 缺失值填充
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 数据标准化
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 拆分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 转换为Tensor
X_train_tensor = torch.tensor(X_train, dtype=torch.float32).unsqueeze(1).transpose(0, 1)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32).unsqueeze(1).transpose(0, 1)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32)

# 初始化模型参数
input_dim = X_train.shape[1]
model = TransformerRegressor(input_dim=input_dim)

# 损失函数与优化器
loss_fn = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

# 模型训练
epochs = 200
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    output = model(X_train_tensor)
    loss = loss_fn(output, y_train_tensor)
    loss.backward()
    optimizer.step()
    if (epoch + 1) % 20 == 0:
        print(f"Epoch {epoch+1}/{epochs}, Loss: {loss.item():.4f}")

# 保存模型
torch.save(model.state_dict(), "Transformer_model_new.pth")
print("✅ 模型保存成功：Transformer_model_new.pth")

# 模型评估
model.eval()
with torch.no_grad():
    y_train_pred = model(X_train_tensor).cpu().numpy()
    y_test_pred = model(X_test_tensor).cpu().numpy()

# MSE 和 R²
train_mse = mean_squared_error(y_train, y_train_pred)
test_mse = mean_squared_error(y_test, y_test_pred)
train_r2 = r2_score(y_train, y_train_pred)
test_r2 = r2_score(y_test, y_test_pred)

print(f"训练集 MSE: {train_mse:.4f}, R²: {train_r2:.4f}")
print(f"测试集 MSE: {test_mse:.4f}, R²: {test_r2:.4f}")


# ========== 计算拟合直线 + 置信区间/预测区间 ==========
def linear_fit_and_bands(y_true, y_pred):
    reg = LinearRegression().fit(y_pred.reshape(-1, 1), y_true)
    slope = reg.coef_[0]
    intercept = reg.intercept_

    residuals = y_true - reg.predict(y_pred.reshape(-1, 1))
    std_err = np.std(residuals)

    # 95%置信区间 & 预测区间（简单估算）
    conf_band = 1.96 * std_err / np.sqrt(len(y_true))
    pred_band = 1.96 * std_err

    return slope, intercept, conf_band, pred_band


train_slope, train_intercept, train_conf_band, train_pred_band = linear_fit_and_bands(y_train.values, y_train_pred)
test_slope, test_intercept, test_conf_band, test_pred_band = linear_fit_and_bands(y_test.values, y_test_pred)

# ========== 绘制测试集拟合图 ==========
plt.figure(figsize=(8, 6))
ax = plt.gca()
ax.spines['bottom'].set_linewidth(1)
ax.spines['left'].set_linewidth(1)
ax.spines['right'].set_linewidth(1)
ax.spines['top'].set_linewidth(1)

plt.xlim(y_test.min() - 0.2, y_test.max())
plt.plot([y_test.min(), y_test.max()],
         [test_slope*y_test.min()+test_intercept, test_slope*y_test.max()+test_intercept],
         color='black', linestyle='dashdot', linewidth=1.5, alpha=0.6, label='Linear Fit')
plt.scatter(y_test_pred, y_test, color='#9932CC', marker='o', alpha=0.9,
            label='Testing Data', edgecolor='black', s=70, linewidth=0.5)
plt.fill_between([y_test.min(), y_test.max()],
                 [test_slope*y_test.min()+test_intercept-test_conf_band, test_slope*y_test.max()+test_intercept-test_conf_band],
                 [test_slope*y_test.min()+test_intercept+test_conf_band, test_slope*y_test.max()+test_intercept+test_conf_band],
                 color='darkgray', alpha=0.5, label='95% Confidence Band')
plt.fill_between([y_test.min(), y_test.max()],
                 [test_slope*y_test.min()+test_intercept-test_pred_band, test_slope*y_test.max()+test_intercept-test_pred_band],
                 [test_slope*y_test.min()+test_intercept+test_pred_band, test_slope*y_test.max()+test_intercept+test_pred_band],
                 color='lightgray', alpha=0.3, label='95% Prediction Band')
plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
plt.xticks(fontsize=30, fontname='Arial', color='black')
plt.yticks(fontsize=30, fontname='Arial', color='black')
plt.tick_params(axis='both', direction='in', length=3)
plt.legend(loc='upper left', frameon=False, prop={'size': 22, 'family': 'Arial'})
plt.text(0.62, 0.02,
         f'Fitting equation:\ny = {test_slope:.2f}x + {test_intercept:.2f}\nR$^2$: {test_r2:.2f}',
         fontsize=25, color='black', ha='left', va='bottom', fontname='Arial', transform=ax.transAxes)
plt.grid(False)
plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/123/Transformer-test_fit.png', dpi=600)
plt.show()

# ========== 绘制训练集拟合图 ==========
plt.figure(figsize=(8, 6))
ax = plt.gca()
ax.spines['bottom'].set_linewidth(1)
ax.spines['left'].set_linewidth(1)
ax.spines['right'].set_linewidth(1)
ax.spines['top'].set_linewidth(1)

plt.xlim(y_train.min() - 0.2, y_train.max())
plt.plot([y_train.min(), y_train.max()],
         [train_slope*y_train.min()+train_intercept, train_slope*y_train.max()+train_intercept],
         color='black', linestyle='dashdot', linewidth=1.5, alpha=0.6, label='Linear Fit')
plt.scatter(y_train_pred, y_train, color='#1E90FF', marker='o', alpha=0.9,
            label='Training Data', edgecolor='black', s=70, linewidth=0.5)
plt.fill_between([y_train.min(), y_train.max()],
                 [train_slope*y_train.min()+train_intercept-train_conf_band, train_slope*y_train.max()+train_intercept-train_conf_band],
                 [train_slope*y_train.min()+train_intercept+train_conf_band, train_slope*y_train.max()+train_intercept+train_conf_band],
                 color='darkgray', alpha=0.5, label='95% Confidence Band')
plt.fill_between([y_train.min(), y_train.max()],
                 [train_slope*y_train.min()+train_intercept-train_pred_band, train_slope*y_train.max()+train_intercept-train_pred_band],
                 [train_slope*y_train.min()+train_intercept+train_pred_band, train_slope*y_train.max()+train_intercept+train_pred_band],
                 color='lightgray', alpha=0.3, label='95% Prediction Band')
plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
plt.xticks(fontsize=30, fontname='Arial', color='black')
plt.yticks(fontsize=30, fontname='Arial', color='black')
plt.tick_params(axis='both', direction='in', length=3)
plt.legend(loc='upper left', frameon=False, prop={'size': 22, 'family': 'Arial'})
plt.text(0.62, 0.02,
         f'Fitting equation:\ny = {train_slope:.2f}x + {train_intercept:.2f}\nR$^2$: {train_r2:.2f}',
         fontsize=25, color='black', ha='left', va='bottom', fontname='Arial', transform=ax.transAxes)
plt.grid(False)
plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/123/Transformer-train_fit.png', dpi=600)
plt.show()

