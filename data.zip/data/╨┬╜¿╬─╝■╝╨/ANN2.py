import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA


# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)


# ------------------ 新增：对C和F做PCA ------------------
# 假设数据集中存在 'C' 和 'F' 两列
cf_features = data[['C', 'F']]

# 标准化
scaler_cf = StandardScaler()
cf_scaled = scaler_cf.fit_transform(cf_features)

# PCA，降到1个主成分（或者2个，你可以改 n_components=2）
pca = PCA(n_components=1, random_state=43)
cf_pca = pca.fit_transform(cf_scaled)

# 将 PCA 结果替换原始 C、F 特征
data_pca = data.drop(columns=['C', 'F']).copy()
data_pca['CF_PCA'] = cf_pca



# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列
#print(y)

# 处理缺失值
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=43)

# 数据归一化
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)


# 创建人工神经网络模型对象
model = MLPRegressor(hidden_layer_sizes=(1000, 1000), activation='relu', solver='adam', random_state=43,learning_rate='constant')

# 拟合模型
model.fit(X_train, y_train)

# 预测测试集数据
#y_pred = model.predict(X_test)
#print(y_pred)

# 将 y_pred 转换为 DataFrame
#df = pd.DataFrame({'y_pred': y_pred, 'y_test': y_test})

# 将 DataFrame 保存到 Excel 文件
#df.to_excel('ANN_predictions_1.xlsx', index=False)

# 预测测试集数据
y_pred_test = model.predict(X_test)
# 预测训练集数据
y_pred_train = model.predict(X_train)

# 计算均方误差（MSE）
test_mse = mean_squared_error(y_test, y_pred_test)
print("测试集均方误差 (MSE): %.2f" % test_mse)

# 计算决定系数（R^2）
test_r2 = r2_score(y_test, y_pred_test)
print("测试集决定系数 (R^2): %.2f" % test_r2)

# 计算训练集的均方误差（MSE）
train_mse = mean_squared_error(y_train, y_pred_train)
print("训练集均方误差 (MSE): %.2f" % train_mse)

# 计算训练集的决定系数（R^2）
train_r2 = r2_score(y_train, y_pred_train)
print("训练集决定系数 (R^2): %.2f" % train_r2)


# 计算拟合直线的斜率和截距（测试集）
test_slope, test_intercept = np.polyfit(y_test, y_pred_test, 1)
# 计算拟合直线的斜率和截距（训练集）
train_slope, train_intercept = np.polyfit(y_train, y_pred_train, 1)

# 计算置信区间和预测区间
def get_confidence_prediction_bands(y_true, y_pred, confidence=0.95):
    n = len(y_true)
    se = np.sqrt(np.sum((y_true - y_pred) ** 2) / (n - 2))
    t_value = 1.96  # for 95% confidence interval

    pred_band = t_value * se * np.sqrt(1 + 1/n)
    conf_band = t_value * se * np.sqrt(1 / n)

    return conf_band, pred_band

test_conf_band, test_pred_band = get_confidence_prediction_bands(y_test, y_pred_test)
train_conf_band, train_pred_band = get_confidence_prediction_bands(y_train, y_pred_train)

# 绘制测试集的拟合图像
plt.figure(figsize=(8, 6))
ax = plt.gca()
ax.spines['bottom'].set_linewidth(1)
ax.spines['left'].set_linewidth(1)
ax.spines['right'].set_linewidth(1)
ax.spines['top'].set_linewidth(1)

# 设置横坐标的长度（范围）
plt.xlim(y_test.min() - 0.2, y_test.max())

plt.plot([y_test.min(), y_test.max()],
         [test_slope*y_test.min()+test_intercept, test_slope*y_test.max()+test_intercept],
         color='black',
         linestyle='dashdot',
         linewidth=1.5,
         alpha=0.6,
         label='Linear Fit')

plt.scatter(y_pred_test, y_test, color='#FFFF00', marker='o', alpha=0.9, label='Testing Data', edgecolor='black', s=70, linewidth=0.5)

# 绘制95%置信区间
plt.fill_between([y_test.min(), y_test.max()],
                 [test_slope*y_test.min()+test_intercept-test_conf_band, test_slope*y_test.max()+test_intercept-test_conf_band],
                 [test_slope*y_test.min()+test_intercept+test_conf_band, test_slope*y_test.max()+test_intercept+test_conf_band],
                 color='darkgray',
                 alpha=0.5,
                 label='95% Confidence Band')

# 绘制95%预测区间
plt.fill_between([y_test.min(), y_test.max()],
                 [test_slope*y_test.min()+test_intercept-test_pred_band, test_slope*y_test.max()+test_intercept-test_pred_band],
                 [test_slope*y_test.min()+test_intercept+test_pred_band, test_slope*y_test.max()+test_intercept+test_pred_band],
                 color='lightgray',
                 alpha=0.3,
                 label='95% Prediction Band')

# plt.xlabel(r'Predicted $q_e$ (mg/g)', fontsize=20, fontweight='bold', color='black', fontname='Arial')
plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')  #设置横纵坐标标签
plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
#plt.title('Test Data: True vs. Predicted values', fontsize=22, fontweight='bold', color='black', fontname='Arial')
plt.xticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')   #设置横纵坐标数值标签     bold
plt.yticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')
# 设置坐标轴短线的开口方向为向内
plt.tick_params(axis='both', direction='in', length=3)

# 调整图例的位置和字体
plt.legend(loc='upper left', frameon=False, prop={'weight': 'normal', 'size': 22, 'family': 'Arial'})

#添加文本
plt.text(0.58, 0.02, f'Fitting equation:\ny = {test_slope:.2f}x + {test_intercept:.2f}\nR$^2$: {test_r2:.2f}',
         fontsize=25, color='black', ha='left', va='bottom', fontname='Arial', fontweight='normal',transform=ax.transAxes)

# 去掉网格
plt.grid(False)

plt.tight_layout()

# 保存测试集拟合图像
plt.savefig('D:/PyCharm/Py_Project/PFAS/123/ANN-test_fit.png', dpi=600)
plt.show()

#####-------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# 绘制训练集的拟合图像
plt.figure(figsize=(8, 6))
ax = plt.gca()
ax.spines['bottom'].set_linewidth(1)
ax.spines['left'].set_linewidth(1)
ax.spines['right'].set_linewidth(1)
ax.spines['top'].set_linewidth(1)

# 设置横坐标的长度（范围）
plt.xlim(y_train.min() - 0.2, y_train.max())

plt.plot([y_train.min(), y_train.max()],
         [train_slope*y_train.min()+train_intercept, train_slope*y_train.max()+train_intercept],
         color='black',
         linestyle='dashdot',
         linewidth=1.5,
         alpha=0.6,
         label='Linear Fit')

plt.scatter(y_pred_train, y_train, color='#00FF00', marker='o', alpha=0.9, label='Training Data', edgecolor='black', s=70, linewidth=0.5)

# 绘制95%置信区间
plt.fill_between([y_train.min(), y_train.max()],
                 [train_slope*y_train.min()+train_intercept-train_conf_band, train_slope*y_train.max()+train_intercept-train_conf_band],
                 [train_slope*y_train.min()+train_intercept+train_conf_band, train_slope*y_train.max()+train_intercept+train_conf_band],
                 color='darkgray',
                 alpha=0.5,
                 label='95% Confidence Band')

# 绘制95%预测区间
plt.fill_between([y_train.min(), y_train.max()],
                 [train_slope*y_train.min()+train_intercept-train_pred_band, train_slope*y_train.max()+train_intercept-train_pred_band],
                 [train_slope*y_train.min()+train_intercept+train_pred_band, train_slope*y_train.max()+train_intercept+train_pred_band],
                 color='lightgray',
                 alpha=0.3,
                 label='95% Prediction Band')

plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')  #设置横纵坐标标签
plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', color='black', fontname='Arial')
#plt.title('Test Data: True vs. Predicted values', fontsize=22, fontweight='bold', color='black', fontname='Arial')
plt.xticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')   #设置横纵坐标数值标签     bold
plt.yticks(fontsize=30, fontweight='normal', fontname='Arial', color='black')
# 设置坐标轴短线的开口方向为向内
plt.tick_params(axis='both', direction='in', length=3)

# 调整图例的位置和字体
plt.legend(loc='upper left', frameon=False, prop={'weight': 'normal', 'size': 22, 'family': 'Arial'})

# 添加文本
plt.text(0.62, 0.02, f'Fitting equation:\ny = {train_slope:.2f}x + {train_intercept:.2f}\nR$^2$: {train_r2:.2f}',
         fontsize=25, color='black', ha='left', va='bottom', fontname='Arial', fontweight='normal', transform=ax.transAxes)

plt.grid(False)
plt.tight_layout()

# 保存训练集拟合图像
plt.savefig('D:/PyCharm/Py_Project/PFAS/123/ANN-train_fit.png', dpi=600)
plt.show()




