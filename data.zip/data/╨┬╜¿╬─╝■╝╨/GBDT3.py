#PAC之后《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《《
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.experimental import enable_iterative_imputer  # 必须有这一行
from sklearn.impute import IterativeImputer
from sklearn.decomposition import PCA

# 读取数据集
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# 提取自变量和因变量
X = data.iloc[:, :-1].copy()  # 自变量
y = data.iloc[:, -1]          # 因变量

# ===== 1. 缺失值填补：IterativeImputer =====
iter_imputer = IterativeImputer(random_state=40, max_iter=10)
X_imputed = pd.DataFrame(iter_imputer.fit_transform(X), columns=X.columns)

# ===== 2. PCA 处理 C 和 F =====
pca = PCA(n_components=1)
C_F_PC = pca.fit_transform(X_imputed[['C', 'F']])

# 删除原来的 C 和 F 列
X_imputed = X_imputed.drop(columns=['C', 'F'])
# 添加主成分
X_imputed['C_F_PC'] = C_F_PC

# ===== 3. 标准化特征 =====
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)

# ===== 4. 划分训练集和测试集 =====
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=40
)

# ===== 5. 定义并训练 GBDT 模型 =====
gbdt_model = GradientBoostingRegressor(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=4,
    random_state=40
)

gbdt_model.fit(X_train, y_train)

# ===== 6. 预测与评价指标 =====
y_pred_train = gbdt_model.predict(X_train)
y_pred_test = gbdt_model.predict(X_test)

train_mse = mean_squared_error(y_train, y_pred_train)
train_r2 = r2_score(y_train, y_pred_train)
test_mse = mean_squared_error(y_test, y_pred_test)
test_r2 = r2_score(y_test, y_pred_test)

print(f"训练集 MSE: {train_mse:.2f}, R²: {train_r2:.2f}")
print(f"测试集 MSE: {test_mse:.2f}, R²: {test_r2:.2f}")

# ===== 7. 拟合直线参数 =====
train_slope, train_intercept = np.polyfit(y_train, y_pred_train, 1)
test_slope, test_intercept = np.polyfit(y_test, y_pred_test, 1)


def plot_fit(y_true, y_pred, slope, intercept, title, save_path, color_data):
    plt.figure(figsize=(8, 6))
    ax = plt.gca()
    ax.spines['bottom'].set_linewidth(1)
    ax.spines['left'].set_linewidth(1)
    ax.spines['right'].set_linewidth(1)
    ax.spines['top'].set_linewidth(1)

    plt.xlim(y_true.min() - 0.2, y_true.max())
    plt.plot(
        [y_true.min(), y_true.max()],
        [slope * y_true.min() + intercept, slope * y_true.max() + intercept],
        color='black', linestyle='dashdot', linewidth=1.5, alpha=0.6, label='Linear Fit'
    )

    plt.scatter(
        y_pred, y_true,
        color=color_data, marker='o', alpha=0.9,
        edgecolor='black', s=70, linewidth=0.5
    )

    # 计算置信区间和预测区间
    n = len(y_true)
    se = np.sqrt(np.sum((y_true - y_pred) ** 2) / (n - 2))
    t_value = 1.96  # 95% 置信区间
    conf_band = t_value * se * np.sqrt(1 / n)
    pred_band = t_value * se * np.sqrt(1 + 1 / n)

    plt.fill_between(
        [y_true.min(), y_true.max()],
        [slope * y_true.min() + intercept - conf_band,
         slope * y_true.max() + intercept - conf_band],
        [slope * y_true.min() + intercept + conf_band,
         slope * y_true.max() + intercept + conf_band],
        color='darkgray', alpha=0.5, label='95% Confidence Band'
    )

    plt.fill_between(
        [y_true.min(), y_true.max()],
        [slope * y_true.min() + intercept - pred_band,
         slope * y_true.max() + intercept - pred_band],
        [slope * y_true.min() + intercept + pred_band,
         slope * y_true.max() + intercept + pred_band],
        color='lightgray', alpha=0.3, label='95% Prediction Band'
    )

    plt.xlabel('Predicted qₑ (mg/g)', fontsize=32, fontweight='normal', fontname='Arial')
    plt.ylabel('Actual qₑ (mg/g)', fontsize=32, fontweight='normal', fontname='Arial')
    plt.xticks(fontsize=30, fontweight='normal', fontname='Arial')
    plt.yticks(fontsize=30, fontweight='normal', fontname='Arial')
    plt.tick_params(axis='both', direction='in', length=3)
    plt.legend(
        loc='upper left',
        frameon=False,
        prop={'weight': 'normal', 'size': 22, 'family': 'Arial'}
    )
    plt.text(
        0.60, 0.02,
        f'Fitting equation:\ny = {slope:.2f}x + {intercept:.2f}\nR²: {r2_score(y_true, y_pred):.2f}',
        fontsize=25, color='black', ha='left', va='bottom',
        fontname='Arial', fontweight='normal', transform=ax.transAxes
    )
    plt.grid(False)
    plt.tight_layout()
    plt.savefig(save_path, dpi=600)
    plt.show()


# 训练集拟合图
plot_fit(
    y_train, y_pred_train, train_slope, train_intercept,
    'Train Fit (IterativeImputer)',
    'D:/PyCharm/Py_Project/PFAS/123/GBDT2-train_fit-iter.png',
    '#228B22'
)

# 测试集拟合图
plot_fit(
    y_test, y_pred_test, test_slope, test_intercept,
    'Test Fit (IterativeImputer)',
    'D:/PyCharm/Py_Project/PFAS/123/GBDT2-test_fit-iter.png',
    '#00FF7F'
)
