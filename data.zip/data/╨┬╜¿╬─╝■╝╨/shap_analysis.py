import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer
import shap

# ------------------- 设置字体和显示 -------------------
plt.rcParams['font.family'] = 'Microsoft YaHei'
plt.rcParams['font.size'] = 16
plt.rcParams['axes.unicode_minus'] = False  # 避免负号显示问题

# ------------------- 读取数据 -------------------
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# ------------------- 提取自变量和因变量 -------------------
X = data.iloc[:, :-1]  # 自变量
y = data.iloc[:, -1]   # 因变量

# ------------------- 缺失值处理 -------------------
imputer = SimpleImputer(strategy='mean')
X_imputed = pd.DataFrame(imputer.fit_transform(X), columns=X.columns)

# ------------------- 划分训练集和测试集 -------------------
X_train, X_test, y_train, y_test = train_test_split(X_imputed, y, test_size=0.2, random_state=39)

# ------------------- 定义 GBDT 回归模型 -------------------
gbdt_model = GradientBoostingRegressor(
    n_estimators=100,
    learning_rate=0.5,
    max_depth=4,
    min_samples_leaf=1,
    min_samples_split=2,
    random_state=20
)

# ------------------- 拟合模型 -------------------
gbdt_model.fit(X_train, y_train)

# ------------------- 计算 SHAP 值 -------------------
explainer = shap.TreeExplainer(gbdt_model)
shap_values = explainer(X_test)

# ------------------- 自定义特征标签 -------------------
y_labels = [
    'C2/C1', 'BET (m²/g)', 'pH', 'T (℃)', 'Time (h)',
    'Log Kow', 'C', 'F'
]


# 检查特征数是否匹配
assert len(y_labels) == X_test.shape[1], "特征标签数量与数据列数不匹配！"

# ------------------- 绘制 SHAP summary plot -------------------
#shap.summary_plot(shap_values.values, X_test, feature_names=y_labels, show=False)

# ------------------- 绘制 SHAP summary plot -------------------
shap.summary_plot(
    shap_values.values,
    X_test,
    feature_names=y_labels,
    show=False,
    plot_size=(10, 8)   # 在这里设置图像大小 (宽, 高)，单位是英寸
)

# 调整 y 轴字体
plt.yticks(fontsize=22, fontname='Microsoft YaHei', weight='bold')

# 调整 x 轴字体
plt.xticks(fontsize=22, fontname='Microsoft YaHei', weight='bold')

# 调整 x 轴标签（SHAP value (impact on model output)）
plt.xlabel("SHAP value (impact on model output)", fontsize=22, fontname='Microsoft YaHei', weight='bold')

# 调整 colorbar 字体
cbar = plt.gcf().axes[-1]  # 获取最后一个轴对象（colorbar）
cbar.tick_params(labelsize=24)  # 调整 colorbar 刻度字体
cbar.set_ylabel("Feature value", fontsize=24, fontname='Microsoft YaHei', weight='bold')  # 修改标签

# 获取当前图像并保存
plt.tight_layout()
plt.savefig('D:/PyCharm/Py_Project/PFAS/fig/SHAP_summary.png', dpi=600)
plt.show()
