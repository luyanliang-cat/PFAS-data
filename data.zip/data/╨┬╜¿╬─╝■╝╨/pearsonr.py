"""
import pandas as pd
import seaborn as sb
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from openpyxl import Workbook, load_workbook
from mpl_toolkits.axes_grid1 import make_axes_locatable
from sklearn.impute import SimpleImputer


# 读取Excel数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data.xlsx'
data = pd.read_excel(file_path)
#df = pd.read_csv('selected_features.csv')

# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 创建并应用SimpleImputer
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 计算所有自变量之间的Pearson相关系数
corr_matrix = data.corr()

 #逐一计算每对自变量之间的相关系数并输出结果
for col1 in corr_matrix.columns:
     for col2 in corr_matrix.columns:
         if col1!= col2:
            corr, p_value = pearsonr(data[col1], data[col2])
#             print(f'自变量 {col1} 和 {col2} 之间的Pearson相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制相关系数的热力图
plt.figure(figsize=(10, 8))
sns.heatmap(data=corr_matrix.round(2), cmap="YlGnBu", annot=True, linewidths=0,
            annot_kws={"fontsize": 15, "fontname": "Arial","fontweight": "bold"},
            cbar_kws={"orientation": "vertical", "shrink": 0.9, "pad": 0.01, "extend": "both"},
            square=True)
# 添加标题
#plt.title('Pearson’s correlation coefficient of features.')
# 修改字体大小
plt.xticks(rotation=45, ha='right',fontsize=17, fontname='Arial',weight='bold')
plt.yticks(rotation=45,fontsize=17, fontname='Arial',weight='bold')
plt.tight_layout()
#plt.savefig('C:/class/result/PCC/Pearson.png')
plt.show()
"""
"""
# 绘制相关系数的热力图
fig, ax = plt.subplots()
im = ax.imshow(corr_matrix, cmap="YlGnBu")
ax.set_xticks(range(len(corr_matrix.columns)))
ax.set_yticks(range(len(corr_matrix.columns)))
ax.set_xticklabels(corr_matrix.columns, fontsize=11, fontname='Arial', rotation=45)
ax.set_yticklabels(corr_matrix.columns, fontsize=11, fontname='Arial', rotation=45)
ax.tick_params(axis='both', which='both', length=0)

# 添加刻度标签
divider = make_axes_locatable(ax)
cax = divider.append_axes("right", size="5%", pad=0.1)
cbar = fig.colorbar(im, cax=cax)
cbar.ax.tick_params(labelsize=9, length=0)

# 添加标题
plt.title('Pearson’s correlation coefficient of features.')

plt.tight_layout()
plt.savefig('C:/class/result/Pearson.png')
plt.show()
"""
"""
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from sklearn.impute import SimpleImputer
from mpl_toolkits.axes_grid1 import make_axes_locatable


# 读取Excel数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data.xlsx'
data = pd.read_excel(file_path)

# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 创建并应用SimpleImputer
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# 创建一个包含自变量和因变量的新DataFrame
data_imputed = pd.DataFrame(X, columns=data.columns[:-1])
data_imputed[data.columns[-1]] = y

# 替换原始数据中的NaN和inf
data_imputed.replace([np.inf, -np.inf], np.nan, inplace=True)
data_imputed.dropna(inplace=True)

# 计算所有自变量之间的Pearson相关系数
corr_matrix = data_imputed.corr()

# 逐一计算每对自变量之间的相关系数并输出结果
for col1 in corr_matrix.columns:
    for col2 in corr_matrix.columns:
        if col1 != col2:
            corr, p_value = pearsonr(data_imputed[col1], data_imputed[col2])
            print(f'自变量 {col1} 和 {col2} 之间的Pearson相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制相关系数的热力图
plt.figure(figsize=(14, 12))
sns.heatmap(data=corr_matrix.round(2), cmap="YlGnBu", annot=True, linewidths=0,
            annot_kws={"fontsize": 10, "fontname": "Arial", "fontweight": "bold"},
            cbar_kws={"orientation": "vertical", "shrink": 0.9, "pad": 0.01, "extend": "both"},
            square=True)
# 添加标题
plt.title('Pearson’s correlation coefficient of features.')
# 修改字体大小
plt.xticks(rotation=45, ha='right', fontsize=10, fontname='Arial', weight='bold')
plt.yticks(rotation=45, fontsize=8, fontname='Arial', weight='bold')
plt.tight_layout()
plt.show()
"""
"""
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from sklearn.impute import SimpleImputer
from mpl_toolkits.axes_grid1 import make_axes_locatable
from sklearn.impute import SimpleImputer

# 读取Excel数据
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
data = pd.read_excel(file_path)

# 提取自变量和因变量
X =data.iloc[:, :-1]  # 自变量，选择除最后一列以外的所有列
y = data.iloc[:, -1]   # 因变量，选择最后一列

# 创建并应用SimpleImputer
imputer = SimpleImputer(strategy='most_frequent')
X = imputer.fit_transform(X)

# 创建一个包含自变量和因变量的新DataFrame
data_imputed = pd.DataFrame(X, columns=data.columns[:-1])
data_imputed[data.columns[-1]] = y

# 替换原始数据中的NaN和inf
data_imputed.replace([np.inf, -np.inf], np.nan, inplace=True)
data_imputed.dropna(inplace=True)

# 计算所有自变量之间的Pearson相关系数
corr_matrix = data_imputed.corr()

# 逐一计算每对自变量之间的相关系数并输出结果
for col1 in corr_matrix.columns:
    for col2 in corr_matrix.columns:
        if col1 != col2:
            corr, p_value = pearsonr(data_imputed[col1], data_imputed[col2])
            print(f'自变量 {col1} 和 {col2} 之间的Pearson相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制相关系数的热力图
plt.figure(figsize=(16, 12))
sns.heatmap(data=corr_matrix.round(2), cmap="YlGnBu", annot=True, linewidths=0.5,
            annot_kws={"fontsize": 10, "fontname": "Arial", "fontweight": "bold"},
            cbar_kws={"orientation": "vertical", "shrink": 0.9, "pad": 0.01, "extend": "both"},
            square=True)

# 添加标题
plt.title('Pearson’s correlation coefficient of features.', fontsize=18, fontweight='bold')
# 修改字体大小
plt.xticks(rotation=45, ha='right', fontsize=12, fontname='Arial', weight='bold')
plt.yticks(rotation=45, fontsize=12, fontname='Arial', weight='bold')
plt.tight_layout()
plt.show()
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from scipy.stats import pearsonr
import os

# 数据路径
file_path = 'D:/PyCharm/Py_Project/PFAS/data/data-1122.xlsx'
save_path = 'D:/PyCharm/Py_Project/PFAS/pearson'
os.makedirs(save_path, exist_ok=True)  # 如果目录不存在就创建

# 读取Excel数据
data = pd.read_excel(file_path)

# 提取自变量和因变量
X = data.iloc[:, :-1]  # 自变量
y = data.iloc[:, -1]   # 因变量

# 缺失值处理
imputer = SimpleImputer(strategy='most_frequent')
X = imputer.fit_transform(X)

# 创建新DataFrame
data_imputed = pd.DataFrame(X, columns=data.columns[:-1])
data_imputed[data.columns[-1]] = y

# 替换inf并删除NaN
data_imputed.replace([np.inf, -np.inf], np.nan, inplace=True)
data_imputed.dropna(inplace=True)

# 计算Pearson相关矩阵
corr_matrix = data_imputed.corr()

# 输出两两相关系数和p值
for col1 in corr_matrix.columns:
    for col2 in corr_matrix.columns:
        if col1 != col2:
            corr, p_value = pearsonr(data_imputed[col1], data_imputed[col2])
            print(f'自变量 {col1} 和 {col2} 之间的Pearson相关系数：{corr:.2f} (p-value: {p_value:.3f})')

# 绘制热力图
plt.figure(figsize=(16, 12))
sns.heatmap(
    data=corr_matrix.round(2), cmap="YlGnBu", annot=True, linewidths=0.5,
    annot_kws={"fontsize": 10, "fontname": "Arial", "fontweight": "bold"},
    cbar_kws={"orientation": "vertical", "shrink": 0.9, "pad": 0.01, "extend": "both"},
    square=True
)

plt.title("Pearson's correlation coefficient of features.", fontsize=18, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontsize=12, fontname='Arial', weight='bold')
plt.yticks(rotation=45, fontsize=12, fontname='Arial', weight='bold')
plt.tight_layout()

# 保存图像
out_file = os.path.join(save_path, "pearson_correlation_heatmap.png")
plt.savefig(out_file, dpi=300, bbox_inches='tight')
plt.close()

print(f"✅ 热力图已保存到: {out_file}")
